import java.io.Serializable;

public interface FunctionInterface extends Serializable {

	int apply(int a);

}
